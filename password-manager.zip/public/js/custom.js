(function ($) {
    'use strict'
    
})(jQuery)
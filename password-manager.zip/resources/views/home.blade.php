@extends('layouts.app')

@section('content')
<div id="app"></div>
@endsection
 